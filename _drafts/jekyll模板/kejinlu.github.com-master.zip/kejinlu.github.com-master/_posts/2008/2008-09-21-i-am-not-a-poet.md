---
layout: post
title: I am not a poet
categories:
- Life
tags:
- 诗
---

I just want to write a poem for you ,  
But fear that I am not a poet.  
I remember your lips and your eyes,  
Your voice,my friend,wanders in my heart,  
Your smile, my friend,left in my soul.  
You smiled,and the sun shined.  
  
All the truth come from the fear of the death,  
All the tears come with the frail of the soul,  
So human is poor when it’s alone,  
Time is short and life is limited,  
But we have a soul,  
whisper to others.  
But we have a wing,  
fly in the mind.  
  
In the whole life ,  
We look for  
the peace of the heart,  
the reason why we lived,  
and the love we wanted.  
  
I wrote these words for you ,  
And for me ,  
To wash my dirty soul with silence.  