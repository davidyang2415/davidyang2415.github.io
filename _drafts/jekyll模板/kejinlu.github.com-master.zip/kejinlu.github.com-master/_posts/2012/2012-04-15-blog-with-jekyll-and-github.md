---
layout: post
title: 使用Jekyll和Github写博客
categories:
- Life
tags:
- blog
- jekyll
- github
---

周末将博客搬到Github上了，使用了[Jekyll](https://github.com/mojombo/jekyll)以及[Github Page](http://pages.github.com)功能，Github Page直接支持Jekyll。
Jekyll是一个博客生成引擎，可以将markdown写成的博客生成静态的HTML博客。
当然Jekyll提供了一些的辅助工具，支持模板，可以辅助你生成分类和标签页。

[Github Page](http://pages.github.com)是Github的一个非常好的服务，免费，可以绑定域名。

这样彻底摆脱了对Wordpress，摆脱了对PHP环境的依赖，博客使用纯文本的形式也方便备份。

