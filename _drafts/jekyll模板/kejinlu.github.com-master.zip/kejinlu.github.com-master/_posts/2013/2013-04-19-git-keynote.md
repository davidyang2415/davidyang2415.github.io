---
layout: post
title: Git命令介绍及内部机制
categories:
- Programming
tags:
- git
---
keynote放在[Speaker Deck](https://speakerdeck.com/kejinlu/gitban-ben-kong-zhi) (github公司创建的一个演示文稿托管服务)，加载有点慢，耐心等待!    

<script async class="speakerdeck-embed" data-id="9c7ac750ac940130d6a626f5cde8fd08" data-ratio="1.33333333333333" src="//speakerdeck.com/assets/embed.js"></script>

