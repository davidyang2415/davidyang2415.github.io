---
title: About me
layout: page
comments: yes
---
  
卢克进, 08年毕业于南京理工大学计算机学院.      
熟练使用常见的计算机语言.      
目前从事Mac,iOS开发相关工作.      

个人邮箱:kejinlu@gmail.com      
新浪微博: [http://weibo.com/kejinlu](http://weibo.com/kejinlu)      
github : [https://github.com/kejinlu](https://github.com/kejinlu)      