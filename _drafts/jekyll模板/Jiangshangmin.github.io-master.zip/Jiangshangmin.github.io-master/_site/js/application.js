$(document).ready(function(){
	var slider = new flux.slider('#slider', {
		pagination: false,
		transitions: ['bars', 'zip', 'blocks']
	});
});