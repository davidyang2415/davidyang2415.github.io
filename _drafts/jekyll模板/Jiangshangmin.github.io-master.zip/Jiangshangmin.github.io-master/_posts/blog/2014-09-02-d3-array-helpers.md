---
layout: post
title: D3.js array tools for data cleaning
description: D3.js itself provides a set of powerful tools, which, if appropriately applied, can easily manipulate data to the desired structures, making the data cleaning  process much less painful.
category: blog
comments: true
---

Data cleaning is a very common task in a data visualization project. I used to rely heavily on Python as the tool to do the most work of data cleaning. Python is a great option, however, it is sometimes a pain in the ass that I have to input the raw data from database to Python for data cleaning, and then output the results to D3.js for data visualization. In fact, D3.js itself is packed with a bunch of tools that allow us to massage the raw data to our desired structures in a very handy way. 

I will walk through some of the common tools that make your life easier. The best way to explain is by examples. (You can find more from [D3 Arrays Documentation][2])

## Array Operators
### d3.range()
d3.range() generates an array containing arithmetic progression, similar to Python built-in [range][1]. d3.range([start, ]stop[, step]) takes up to three arguments, and two of them are optional.
#### start
The argument start is defaults to 0 and decides where the range array starts.
#### stop
The argument stop is required and will determine where the range array stops. The top number will not be included in the range array.
#### step
The argument step is optional and defaults to 1. It determines how quickly the range array increments or decrement value by value. If set to positive, then the last value will be the largest, and if negative, the first value is the largest. Step can be set to be a float, not just integers, which is different to Python range.

    d3.range(10) // returns [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    d3.range(2, 7) // returns [2, 3, 4, 5, 6]
    d3.range(2, 7, 2) // returns [2, 4, 6]
    d3.range(2, 7, 1.2) // returns [2, 3.2, 4.4, 5.6, 6.8]

### d3.permute()
d3.permute(array, indexes) generates the permuations of given array based upon the positions provided. It takes two arguments:    
#### array
The original array we are going to run permutations on.

#### indexes
The indexed are a list of integers representing the locations of each element in the arranged array.

    d3.permute(['a', 'b', 'c'], [2, 1, 0]) // returns ["c", "b", "a"]
    d3.permute(['a', 'b', 'c'], [1, 1, 0, 2]) // returns ["b", "b", "a", "c"]
    d3.permute(['a', 'b', 'c'], [1, 4]) // returns ["b", undefined]

### d3.merge(arrays)
It merges array of arrays to a single array.

    d3.merge([[1, 2], [3, 4], ['a', 'b', 'c']]);
    //returns [1, 2, 3, 4, "a", "b", "c"]

    d3.merge([[1, 2], [3, 4, ['a', 'b', 'c']]]);
    //returns [1, 2, 3, 4, ["a", "b" ,"c"]]

### d3.zip(arrays)
It returns a list of arrays, where the i-th element from each of the argument arrays.

    d3.zip([1, 2], [3, 4]);
    //returns [[1, 3], [2, 4]]

    d3.zip([1, 2], [3, 4, 5]);
    //returns [[1, 3], [2, 4]]

    d3.zip([1, 2])
    //returns [[1], 2]

    d3.zip([1, 2], [3, 4], [5, 6])
    //returns [[1, 3, 5], [2, 4, 6]]

### d3.transpose(array)
Return the transposition of a matrix(defind as an array of arrays here). If A is a m x n matrix, then transposition of A is an n x m matrix.

    var matrix = [[1, 2, 3], [4, 5, 6]];
    d3.transpose(matrix);//returns [[1, 4], [2, 5], [3, 6]]

    d3.transpose([[], [1, 2]]); //returns []
    d3.transpose([[1], [1, 2]]); //returns [1]

### d3.pairs(array)
For each adjacent pair of elements in the specified array, returns a new array of tuples of element i and element i - 1. For example:

    d3.pairs([1, 2, 3, 4]); //returns [[1, 2], [2, 3], [3, 4]]
    d3.pairs([1]); //returns []
    d3.pairs([1, 2]); //returns [[1, 2]]

### array.forEach()
The array.forEach(callback[, thisArg]) method is used to iterate over the array items. It requires at most two arguments:
#### callback
The callback is a function which will be executed on every single element in the array. It takes three arguments:

* `currentValue`
The current element being processed in the array.
* `index` 
The index of the current element being processed in the array.
* `array`
The array `forEach` was called upon, i.e., the original array being iterated

#### thisArg
Value to use as `this` when executing `callback`.

    ['a', 'b', 'c'].forEach(function(d, i, arr) {
    	console.log(d, i, arr)
    	})
    //returns 
    //a 0 ["a", "b", "c"]
    //b 1 ["a", "b", "c"]
    //c 2 ["a", "b", "c"]



### array.map()
Similar to array.forEach(), array.map(callback[, thisArg]) is used to iterate over items in the given array. The difference is, it returns the item after calling the `callback` upon so that it allows us to create a new array with the same length as the original one.

    [1, 2, 3].map(function(d) {
    	return 'f(' + d + ')'
    	})
    //returns ["f(1)", "f(2)", "f(3)"]

### array.filter()
array.filter(callback[, thisArg]) returns a new array based on the truth test provided by callback function.

    [3, 4, 5, 6, 7, 8, 9].filter(function(d) {
    	return (d % 2 === 0)
    })
    //returns [4, 6, 8]

### array.sort()
The array.sort([compareFunction]) sorts the elements of an array `in place`, meaning it does not return a new array but instead returns the original.

####compareFunction
Specifies a function that defines the sort order. If omitted, the array is sorted lexicographically, NOT numerically by default. This means it sorts the elements according to the string conversion of each element.
If `compareFunction` is specified, the array elements are sorted according to the return value of the compare function. If a and b are two elements being compared, then:

* if compareFunction(a, b) is less than 0, then a comes first.
* if compareFunction(a, b) returns 0, then leave a and b unchanged.
* if compareFunction(a, b) is larger than 0, then b comes first.

For examples,

    var original = ['Welcome', 'to', 'my', 'blog'];
    var sorted = original.sort();
    sorted; //["Welcome", "blog", "my", "to"]
    original; //["Welcome", "blog", "my", "to"]

    var nums = [3, 2, 1, 5, 6, 10, 8, 4, 9, 7];
    nums.sort(); // returns [1, 10, 2, 3, 4, 5, 6, 7, 8, 9]
    
    nums.sort(function(a, b){
    return a - b;
    }); //returns [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

## Ordering
### d3.ascending()/d3.descending()
They are very much like the `compareFunction` in array.sort() method. They accept two arguments: a and b. 
* d3.ascending(a, b) returns -1 if a is less than b; returns 1 if a is larger than b; 0 if equal.
* d3.descending(a, b) returns the opposite.
Of course they can be passed into the array.sort() method. For example:

    var nums = [1, 5, 3, 8];
    arr.sort(d3.ascending); //returns [1, 3, 5, 8]
    arr.sort(d3.descending); //returns [8, 5, 3, 1]

### d3.shuffle(array)
This method randomizes the elements of the given array.

### d3.extent(array)
It returns the minimum and maximum of the array:
   
    d3.extent([3, 0, 5, 7]); //returns [0, 7]

### d3.quantile(numbers, p)
It returns the p-quantile of the numbers, where p is a number between [0, 1]. For the quantile to work properly, the numbers array must be already sorted in ascending order.

	var nums = [1, 3, 5, 7, 9];
    d3.quantile(nums, 0.5); //returns 5
    d3.quantile(nums, 0.25); //returns 3

    d3.quantile([1, 5, 3], 0.5); //returns 5, NOT 3 because the numbers are not sorted.

### d3.min(), d3.max(), d3.sum(), d3.mean(), and d3.median()
They return the minimal, maximum, summation, average and median of the given array respectively. They all share the same usage like d3.min(array[, accessor]), for example.

    var nums = [0, 50, 20, 10];
    d3.min(nums); //returns 0
    d3.max(nums); //return 50
    d3.mean(nums); //return 20
    d3.sum(nums); //return 80
    d3.median(nums); //return 15

    //with accessor supplied
    var nums = [{x: 'a', y: 0}, {x: 'b', y: 50}, {x: 'c', y: 20}, {x: 'd', y: 10}]
    d3.min(nums, function(d) { return d.y; }) //returns 0
    d3.sum(nums, function(d) { return d.y; }) //returns 80

## Associative Arrays
### d3.keys(object)
It returns an array of key names of the given object.

    d3.keys({'x': 1, 'y': 2, 'z': 3}); //returns ['x', 'y', 'z']

### d3.values(object)
It returns an array containing all the values of the given object.

    d3.values({'x': 1, 'y': 2, 'z': 3}); //returns [1, 2, 3]

### d3.entries(object)
It returns an array containing the keys and values of the given object. Each entry is an object with a key and value attribute.

    d3.entries({x: 1, y: 2});
    //returns [{key: 'x', value: 1}, {key: 'y', value: 2}]





[1]: https://docs.python.org/2/library/functions.html#range "range"
[2]: https://github.com/mbostock/d3/wiki/Arrays "D3 document"

