---
layout: post
title: 我是如何把这个博客建起来的
description: 使用Github Pages可以很方便地建立自己的独立博客，无限流量而且免费。这篇文章记录了我自己从域名购买到最后把网站搭建起来的流程，涉及到 Git + Jekyll + Github Pages + Disqus
category: blog
comments: true
---

趁着这个Laber Day的周末，总算把拖了许久的个人博客网站给搭起来了。嗯，貌似建好博客的惯例通常是把初篇献给“我为什么写博客”这个主题。不过在我看来，更要紧的是趁自己对这一切还有印象的时候，梳理一下流程，以免将来遗忘，也希望对后来者有所帮助。

大致说来，整个建站从域名开始，涉及到以下服务及技术：

* [Godaddy][]上注册购买域名，域名解析使用[DNSPod][]
* 将代码托管在[Github][]，使用[Github Pages][]来发布网站
* 使用[Jekyll][]模板系统，编写整个网站
* 使用[Disqus][]托管评论

除了域名购买需要花点银两，剩下的服务全部免费。

## 购买绑定个性域名

直奔[Godaddy][]，注册邮箱验证这些常规手续就不说了。然后在搜索框中输入自己想要的域名，点击查看是否可以注册。当你选定域名后，进入付款环节，系统会提供一些需要额外付费的推荐服务，比如隐私保护，域名邮箱，网站空间等，不想买就不用管，结账！

虽然[Godaddy][]家也提供域名解析服务，毕竟是国外的服务器，出于对可能被墙的而导致域名无法访问的担忧，还是把域名解析服务迁移到国内比较稳定的服务商处。不用担心，这个过程不会对你的域名所有权产生任何影响。

[DNSPod][]家的服务很好用，而且免费，整个过程简单到没有给我留下任何可折腾的空间。 官方的[帮助文档][1]已经有了很详实的介绍，包括[godaddy注册的域名如何使用DNSPod][2],只需三步即可。

不过由于我们接下来会使用[Github Pages][]来发布网站，因此需要额外插入一步： 在DNSPod自己的域名下添加两条A记录(或者修改原有存在的那条A记录并添加一条)，地址分别为：192.30.252.153 和 192.30.252.154，正是Github Pages的服务IP地址。最终效果如下：
![](/images/githubpages/DNSPod.png)

域名的配置部分完成，需耐心等待解析生效。

## 使用Github Pages建立博客
在此之前，你需要对Git和Github有基本的了解和掌握。这里有一份不错的[基础教程][3]，或者查看[官方文档][4]。

### User Pages
顺利与Github建立连接后，点击其主页面右上角你的用户名旁边的加号，创建一个新的repository，这里将是你用来托管网站代码的仓库。为了使用Pages的服务，repo的名字必须形如`username.github.io`，比如我的repo名字就是`Jiangshangmin.github.io`，Jiangshangmin是我的用户名。

创建好后，让我们来实操一个最简单的hello world网站。
打开terminal，创建一个目录，用来存放我们刚刚新建的repo：

    $ makir /path/to/source-code
    $ cd /path/to/source-code

或者，直接存放在根目录上：

    $ cd ~

把新建的repo clone下来：

    $ git clone https://github.com/username/username.github.io.git
    $ cd username.github.io

创建显示'hello world'的网页：

    $ echo "Hello, World" > index.html

add, commit，push你的代码到Github的mater分支，也就是主干上。

    $ git add index.html
    $ git commit -m 'my first commit'
    $ git push origin master

然后静等页面生效。第一次需要一些时间，稍等最多10分钟，以后基本就是秒更了。
生效之后，访问`http://username.github.io/`， 就可以看到你上传的显示`Hello, World`的页面了。

###绑定个性域名
在之前DNS部分的设置里，我们已经添加了Github的两条A记录。要想让`username.github.io`通过你自己的域名来访问，只需要在repo的根目录下新建一个名为`CNAME`的文件，内容形如：mydomain.com 。比如我的就是 shanejiang.com

    $ echo 'mydomain.com' > CNAME

如果有ERROR，点击[这里][custom-domain]查看获取帮助。
至此，网站已经能顺利通过你自己的域名发布了，剩下的就是网页内容了。

##Jekyll

Jekyll是一个简单的免费的Blog生成工具, 一个强大的静态模板系统，不需要数据库支持。它可以配合第三方服务,例如disqus，也就是我们接下来会涉及到的评论托管服务。最关键的是jekyll可以免费部署在Github上，而且可以绑定自己的域名。

###搭建Jekyll本地环境

使用Gem安装jekyll
    
    $ gem install jekyll

顺利安装结束后，我们先新建一个jekyll-demo的初始项目来熟悉一下Jekyll的基本结构:
    
    $ cd ~
    $ jekyll new jekyll-demo
    $ cd jekyll-demo
    $ jekyll serve

通过访问`localhost: 4000`，你就可以看到Jekyll默认的基本页面效果，如下所示：
![](/images/githubpages/Jekyll_demo.jpg)

###Jekyll模板系统
为了定制自己的网站，必须要对Jekyll的基本结构有所了解：

	|-- _config.yml
    |-- _includes
    |   |-- head.html
    |   |-- header.html
    |   `-- footer.html
    |-- _layouts
    |   |-- default.html
    |   |-- page.html
    |   `-- post.html
    |-- _posts
    |   `-- 2014-08-31-welcome-to-jekyll.markdown
    |-- _site 
    `-- index.html

####_config.yml
配置文件，用来定义一些环境变量，放在这个文件里比较方便。比如初始默认的_config.yml:

	# Site settings
	title: Your awesome title
	email: your-email@domain.com
	description: > # this means to ignore newlines until "baseurl:"
	  Write an awesome description for your new site here. You can edit this
	  line in _config.yml. It will appear in your document head meta (for
	  Google search results) and in your feed.xml site description.
	baseurl: "" # the subpath of your site, e.g. /blog/
	url: "http://yourdomain.com" # the base hostname & protocol for your site
	twitter_username: jekyllrb
	github_username:  jekyll

	# Build settings
	markdown: kramdown

在接下来的文件中，通过`{ { site.title }}`就可以很方便地调用这里定义的title变量了。

####_includes
这里面存放的是一些可重复利用的小文件或模板。你可以在其他文件里通过`{％ include filename.ext ％}`这样的命令来调用_includes/filename.ext。
举个例子，以下是_layouts/default.html的代码

	<!DOCTYPE html>
	<html>
	  {％ include head.html ％}
	  <body>
	    {％ include header.html ％}
	    <div class="page-content">
	      <div class="wrapper">
	        { { content }}
	      </div>
	    </div>
	    {％ include footer.html ％}
	  </body>
	</html>

`{％ include head.html ％}`表示此处调用_includes/head.html的内容，同理，`{％ include footer.html ％}`表示调用_includes/footer.html的内容。

`{ { content }}`表示在调用模板后，每个页面的具体内容会被填充到这里，这个暂且搁在这里，接下来会马上提到它实际中的使用例子。这个content两边的双重大括号，是一种叫做[Liquid][]的标记语言。


####_layouts
存放模板文件的地方，最终的网页文件就是通过这些模板拼接起来的。
以下是_layouts/post.html的代码。

	---
	layout: default
	---
	<div class="post">

	  <header class="post-header">
	    <h1 class="post-title">{ { page.title }}</h1>
	    <p class="post-meta">{ { page.date | date: "%b %-d, %Y" }}{% if page.author %} • { { page.author }}{% endif %}{% if page.meta %} • { { page.meta }}{% endif %}</p>
	  </header>

	  <article class="post-content">
	    { { content }}
	  </article>

	</div>

开头被`---`限定的是一些可以在解析时被引用的变量，我们称之为`YAML Front Matter`，会受到Jekyll的特别对待。这里的font-matter起到的作用就是告诉Jekyll在生成网页文件index.html时，去_layouts目录下找名为default.html的文件，然后在解析当前文件后，所有内容填充到default.html的`{ { content }}`部分里，这里就是以上提到的马上出现的实际例子。注意到page.html里也有一个`{ { content }}`，它表示的是，当有其他文件调用_layouts/page.html时，该文件解析后的内容将会被填充到page.html的`{ { content }}`里。

此处的`{ { page.title }}`和`{ { page.date }}`填充的是调用post.html的文件里所自定义的title变量和date变量。比如，以下是_posts/2014-08-31-welcome-to-jekyll.markdown的开头部分内容。

	---
	layout: post
	title:  "Welcome to Jekyll!"
	date:   2014-08-31 12:41:53
	categories: jekyll update
	---
	You’ll find this post in your `_posts` directory. Go ahead and edit it and re-build the site to see your changes. You can rebuild the site in many different ways, but the most common way is to run `jekyll serve --watch`, which launches a web server and auto-regenerates your site when a file is updated.

`_posts/2014-08-31-welcome-to-jekyll.markdown`调用`_layouts/post.html`，前者定义的`title`将被填充到后者的`{ { page.title }}`，page对象被用来接受所有未被预定义的自定义变量。方向上刚好跟`{ { content }}`的填充相反。

####_posts
博客正文的存在位置, 有其特定的命名规则，必须使用以下统一的格式：
    
    YEAR-MONTH-DATE-title.MARKUP

MAERKUP是你所使用的标记语言的后缀名。 这个文件名会被解析成post.date和post.title变量，供其调用。比如根目录下的index.html文件:

	---
	layout: default
	---

	<div class="home">
	  <h1 class="page-heading">Posts</h1>
	  <ul class="post-list">
	    {% for post in site.posts %}
	      <li>
	        <span class="post-meta">{ { post.date | date: "%b %-d, %Y" }}</span>
	        <h2>
	          <a class="post-link" href="{ { post.url | prepend: site.baseurl }}">{ { post.title }}</a>
	        </h2>
	      </li>
	    {% endfor %}
	  </ul>
	  <p class="rss-subscribe">subscribe <a href="{ { "/feed.xml" | prepend: site.baseurl }}">via RSS</a></p>
	</div>

其中的`{ { post.date }}`和`{ { post.title }}`就是由文件名解析而来。`{ { post.url }}`的解析则是由`Permalink`得来。

`Permalink`项用来定义你最终的文章链接是什么形式，它有下面几个变量：

* `year` 文件名中的年份
* `month` 文件名中的月份
* `day` 文件名中的日期
* `title` 文件名中的文章标题
* `categories` 文章的分类，如果文章没有分类，会忽略
* `i-month` 文件名中的除去前缀0的月份
* `i-day` 文件名中的除去前缀0的日期

看看最终的配置效果：

* `permalink: pretty` /2009/04/29/slap-chop/index.html
* `permalink: /:month-:day-:year/:title.html` /04-29-2009/slap-chop.html
* `permalink: /blog/:year/:month/:day/:title` /blog/2009/04/29/slap-chop/index.html

更多模板变量，可以参考[官方文档][6]


####_site
Jekyll最终生成的文件将会存放在此。

####index.html
这里就是网站主页的html文件

通过摆弄这些初始文件，并参考[这里][5]丰富的Jekyll主题网站源码，可以帮助自己学习理解并获(piao)取(qie)网站设计灵感。

至此，Jekyll介绍完毕。你可以在我们之前创建的`username.github.io`repo中，开始为个人网站的最终完成添砖加瓦了。当然你也可以直接fork[这里][5]的source，修改使用别人的模板。

##Disqus评论托管
Jekyll本身不提供评论功能，所以必须使用第三方的服务来托管服务，如Disqus. 注册登录略过不表。点击`Add Disqus to your site`，你需要输入Site name，和一个unique Disqus URL，两者默认相关，但是你可以随意更改，然后点击完成。

在随后提供的多种平台中，选择第一个Universal Code即可。它会根据你之前提供的信息，自动生成一个shortname在以下代码片段中：
	
	<script type="text/javascript">
	        /* * * CONFIGURATION VARIABLES: EDIT BEFORE PASTING INTO YOUR WEBPAGE * * */
	        var disqus_shortname = 'shanejiang'; // required: replace example with your forum shortname

	        /* * * DON'T EDIT BELOW THIS LINE * * */
	        (function() {
	            var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
	            dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
	            (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
	        })();
	    </script>
	    <noscript>Please enable JavaScript to view the <a href="http://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
	    <a href="http://disqus.com" class="dsq-brlink">comments powered by <span class="logo-disqus">Disqus</span></a>
	    
比如在这里我shortname的就是'shanejiang'。然后将这段代码添加到_layouts/post.html中你希望它出现的位置上去。这样子的话你的每一篇blog都将会允许加载评论功能。但有时候你希望对某些文章关闭评论功能，这里有个小技巧可以很方便的实现对每篇blog评论功能开关的控制。是否还记得，所有在`YAML Front Matter`里非预定义的变量都会被自动塞到page对象里。也就是说，我可以在每一篇blog的front－matter里添加变量`comments: true`或者`comments: false`来设置是否开启评论, 然后在_layouts/post.html目标位置插入

	｛％ if page.comments ％｝
	   <script type="text/javascript">
	        /* * * CONFIGURATION VARIABLES: EDIT BEFORE PASTING INTO YOUR WEBPAGE * * */
	        var disqus_shortname = 'shanejiang'; // required: replace example with your forum shortname

	        /* * * DON'T EDIT BELOW THIS LINE * * */
	        (function() {
	            var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
	            dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
	            (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
	        })();
	    </script>
	    <noscript>Please enable JavaScript to view the <a href="http://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
	    <a href="http://disqus.com" class="dsq-brlink">comments powered by <span class="logo-disqus">Disqus</span></a>
	{％ endif ％}

这样就可以了！

##结语
个人网站设计，一切从零开始，深受[Beiyuu][] blog的影响和帮助，他的界面简洁清爽，个人非常喜欢，特此感谢！











[Godaddy]:	www.godaddy.com "Godaddy"
[Github]:	www.github.com "Github"
[Github Pages]: pages.github.com "Github Pages"
[DNSPod]: www.dnspod.cn "DNSPod"
[Jekyll]: http://jekyllrb.com "Jekyll"
[Disqus]: https://disqus.com "Disqus"
[Liquid]: https://github.com/Shopify/liquid "Liquid"
[1]: https://support.dnspod.cn/Kb/showarticle/tsid/177/
[2]: https://support.dnspod.cn/Kb/showarticle/?qtype=%E5%8A%9F%E8%83%BD%E4%BB%8B%E7%BB%8D%E5%8F%8A%E4%BD%BF%E7%94%A8%E6%95%99%E7%A8%8B&tsid=42
[3]: https://www.atlassian.com/git/tutorial/git-basics "Git Basics"
[4]: https://help.github.com/ "Github Help"
[5]: https://github.com/jekyll/jekyll/wiki/Sites "Jekyll Themes"
[6]: https://github.com/mojombo/jekyll/wiki/template-data "Jekyll Template Data"
[custom-domain]: https://help.github.com/articles/my-custom-domain-isn-t-working "Custom Domain"
[Beiyuu]: http://beiyuu.com/ "Beiyuu"